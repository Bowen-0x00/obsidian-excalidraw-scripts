/*
```javascript
*/
let api = ea.getExcalidrawAPI();
        
console.log("deleteSelectedElementsHook")

function DeleteOrphanMindmap(node, elementMap) {
    if (node) {
        let el = elementMap.get(node.id)
        if (el?.customData?.mindmap) {
            delete el.customData.mindmap

            node.children.forEach(n => {
                DeleteOrphanMindmap(n, elementMap)
            })
           
        }
    }
}

window.deleteSelectedElementsHook = function(elements, appState) {
    console.log("deleteSelectedElementsHook")
    ea.setView("active");
    const selectedEls = ea.getViewSelectedElements();
    let elementMap = new Map();
    elements.forEach(el => elementMap.set(el.id, el))
    selectedEls.forEach(el => {
        if (el?.customData?.mindmap && el.id != el.customData.mindmap.root) {
            if (window?.customData?.Mindmap?.mindmapPosMap && window.customData.Mindmap.mindmapPosMap.has(el.customData.mindmap.root)) {
                let obj = window.customData.Mindmap.mindmapPosMap.get(el.customData.mindmap.root)
                let node = obj.NodeMap.get(el.id)
                let parentNode = node.parent
                let deleteArrow;
                if (parentNode) {
                    let arrows = []
                    
                    parentNode.childrenArrow.forEach(arrow => {
                        if (arrow?.endBinding?.elementId) {
                            if (arrow.endBinding.elementId != node.id) {
                                arrows.push(arrow)
                            } else {
                                deleteArrow = arrow
                            }
                        }
                        
                    })
                    parentNode.childrenArrow = arrows
                    let children = new Set(parentNode.children)
                    children.delete(node)
                    parentNode.children = [...children]
                    node.children.forEach(el => {
                        DeleteOrphanMindmap(el, elementMap)
                    })
                    ea.clear()
                    obj.NodeMap.delete(node.id)

                    
                }
                if (deleteArrow) {
                    appState.selectedElementIds[deleteArrow.id] = true
                    
                }
            }
        }
    })

    
}