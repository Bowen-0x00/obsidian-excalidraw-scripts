/*
```javascript
*/

console.log("replace mindmap node")
const api = ea.getExcalidrawAPI();
const selectedEls = ea.getViewSelectedElements();
let elements = api.getSceneElements()

// function getElementsAtPosition(elements, x, y) {
//   els = elements.filter((el) => {
//     if (el.type == "arrow")
//       return false
//     let box = ea.getBoundingBox([el])
//     return  x >= box.topX && x <= box.topX + box.width && y >= box.topY && y <= box.topY + box.height;
//   })
//   els.sort(function(a, b){return (x-a.x)**2 + (y-a.y)**2 - ((x-b.x)**2 + (y-b.y)**2)});
//   return els;
// }


// let position = ExcalidrawAutomate.targetView.currentPosition

// let targetEl = getElementsAtPosition(elements, position.x, position.y).filter(el => el.id != selectedEl.id)[0]

let targetEl, selectedEl;
selectedEls.forEach(el => {
  if (el.text && el.text=="new element")
      return
  if (el?.customData?.mindmap) {
    targetEl = el
  }
  else {
    selectedEl = el
  }
})

selectedEl.customData = {
  ...selectedEl.customData,
  mindmap: targetEl?.customData?.mindmap
}
let obj = window.customData.Mindmap.mindmapPosMap.get(selectedEl.customData.mindmap.root)
let oldNode = obj.NodeMap.get(targetEl.id)
let arrowEl = elements.filter(el => el.id == oldNode.parentArrow.id)[0]
arrowEl.endBinding.elementId = selectedEl.id
selectedEl.boundElements = selectedEl.boundElements || []
selectedEl.boundElements.push({type: "arrow", id: arrowEl.id})
// oldNode.parent.children = oldNode.parent.children.filter(el => el.id != oldNode.id)
oldNode.id = selectedEl.id

obj.NodeMap.delete(targetEl.id)
obj.NodeMap.set(oldNode.id, oldNode)
let textEl = targetEl.boundElements.filter(el => el.type=="text")[0]
textEl = elements.filter(el => el.id == textEl.id)[0]

ea.clear()
ea.deleteViewElements([textEl, targetEl]);
ea.copyViewElementsToEAforEditing([selectedEl, arrowEl]);
ea.addElementsToView();
new Notice("replace mindmap node");