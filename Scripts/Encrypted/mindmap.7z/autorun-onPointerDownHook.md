/*
```javascript
*/
console.log("autorun-onPointerDownHook")
let api = ea.getExcalidrawAPI();
            
// state.zoom = {value: 0.8}
// drawElementOnCanvasHook(context, rc, element, shape, renderConfig)
// renderElementHook
console.log("onPointerDown_Hook")
function changeElementsVisiable(visiable, elements) {
    let locked = visiable ? false : true;
    
    elements.forEach((el) => {
        let opacity;
        if (visiable) {
            opacity = el?.customData?.backup_opacity || 100;
        } else {
            el.customData = el.customData || {}
            el.customData.backup_opacity = el.opacity;
            opacity = 0;
        }

        el.locked = locked;
        el.opacity = opacity;
    })
    // ea.copyViewElementsToEAforEditing(elements)
    // ea.addElementsToView(false,true,false);
}
class Node {
    constructor(element) {
        this.parent = null
        this.parentArrow = null
        this.children = []
        this.childrenArrow = []
        this.level = element.customData.mindmap.level
        this.id = element.id
    }
}



window.onPointerDown_Hook= function(view, event) {
    if (event.shiftKey) {
        setTimeout(async () => {
            let selectElements = view.getViewSelectedElements()
            if (selectElements.length > 0) {
                let element = selectElements[0]
                if (element.customData) {
                    if ("collapse" in element.customData) {
                        console.log("collapse")
                        let collapse = element.customData.collapse
                        // let ids = collapse.el.map((el) => {return el.id})
                        api = api || ea.getExcalidrawAPI()
                        let elements = api.getSceneElements()
                        let collapseElements = elements.filter((el) => {
                            {return collapse.el.contains(el.id)}
                        })
                        let openElements = elements.filter((el) => {
                            {return collapse.openElementIds.contains(el.id)}
                        })
                        let closeElements = elements.filter((el) => {
                            {return collapse.closeElementIds.contains(el.id)}
                        })
                        api.App.deselectElements()

                        if (collapse.status == "open") {
                            collapse.status = "closed"
                            changeElementsVisiable(false, collapseElements.concat(openElements))
                            changeElementsVisiable(true, closeElements)
                        } else if (collapse.status == "closed") {
                            collapse.status = "open"
                            changeElementsVisiable(false, closeElements)
                            changeElementsVisiable(true, collapseElements.concat(openElements))
                        }
                        openElements.concat(closeElements).forEach((el) => {
                            el.customData.collapse.status = collapse.status
                        })
                        ea.copyViewElementsToEAforEditing(openElements.concat(closeElements).concat(collapseElements))
                        await ea.addElementsToView(false,false,false);
                        
                    }
                    if ("onPointerDownHook" in element.customData) {
                        if (!api) api = ea.getExcalidrawAPI();
                        api.App.deselectElements()
                        return new Function("el", `${element.customData.onPointerDownHook}`)(element);
                    }                  
                    if ("mindmap" in element.customData) {
                        console.log("mindmap")
                        window.customData = window?.customData || {}
                        window.customData.Mindmap = window.customData?.Mindmap || {}
                        window.customData.Mindmap.mindmapPosMap = window.customData.Mindmap?.mindmapPosMap || new Map()
                        

                        api = api || ea.getExcalidrawAPI();
                        let elements = ea.getViewElements()
                        let elementMap = new Map();
                        elements.forEach(el => elementMap.set(el.id, el))
                        // ea.copyViewElementsToEAforEditing(elements);
                        let arrowElements = elements.filter((el) => {return el.type=="arrow"})
                        //init data struct
                        let obj = {}
                        if (!window.customData.Mindmap.mindmapPosMap.has(element.customData.mindmap.root) || !window.customData.Mindmap.mindmapPosMap.get(element.customData.mindmap.root)) {
                            let rootEl = elementMap.get(element.customData.mindmap.root)
                            obj = {}
                            obj.NodeMap = new Map()

                            function traverse(element, parentNode, level, arrow) {
                                let startArrowElements = arrowElements.filter((el) => {return el.startBinding && el.startBinding.elementId==element.id})
                                if (!element?.customData?.mindmap) {
                                    element.customData = {
                                        ...element.customData,
                                        mindmap: {
                                            status: "open",
                                            root: rootEl.id,
                                            parent: parentNode.id,
                                            level: parentNode.level+1
                                        }
                                    }
                                }
                                let node = new Node(element)
                                if (level == 1) obj.rootNode = node
                                obj.NodeMap.set(node.id, node)
                                node.parent = parentNode
                                parentNode && parentNode?.children.push(node)
                                node.parentArrow=arrow
                                startArrowElements.forEach((el) => {
                                    node.childrenArrow.push(el)
                                    let child = elementMap.get(el.endBinding.elementId)
                                    traverse(child, node, level+1, el)
                                })
                            }
                            traverse(rootEl, null, 1)
                            window.customData.Mindmap.mindmapPosMap.set(element.customData.mindmap.root, obj)
                        }
                        //get children elements
                        let children = []
                        let arrows = []
                        function getChildren(node, recursion=true, filter=undefined) {
                            if (filter && node.children.length && filter(node.children[0])) {
                                return
                            }
                            children = children.concat(node.children)
                            arrows = arrows.concat(node.childrenArrow)
                            
                            if (recursion) {    
                                node.children.forEach(el => {
                                    getChildren(el, true, filter)
                                })
                            }
                        }

                        // element = elementMap.get(element.id)
                    
                        obj = window.customData.Mindmap.mindmapPosMap.get(element.customData.mindmap.root)
                        NodeMap = obj.NodeMap
                        let node = NodeMap.get(element.id)
                        let recursion = false
                        let visiable = false
                        let status = "open"
                        async function op(recursion, visiable, status) {
                            getChildren(node, recursion)
                            children = children.map((el) => {
                                return elementMap.get(el.id)        
                            })
                            children = children.filter(el => el)
                            arrows = arrows.map((el) => {
                                return elementMap.get(el.id)        
                            })
                            arrows = arrows.filter(el => el)
                            boundElements = []
                            children.forEach(el => {
                                if (el.boundElements) {
                                    el.boundElements.forEach(el => {
                                        if (el.type!="arrow") {
                                            boundElements.push(elementMap.get(el.id))
                                        }
                                    }) 
                                }
                            })
                            let groupElements = []
                            
                            children.forEach(el => {
                                groupElements = groupElements.concat(ea.getElementsInTheSameGroupWithElement(el, elements).filter(el => !el?.customData?.zoomHide))
                            })
                            element?.customData?.mindmap && (element.customData.mindmap.status = status)
                            if (status == "close") {
                                children.forEach((el) => {
                                    el = elementMap.get(el.id)
                                    el?.customData?.mindmap && (el.customData.mindmap.status = "close")
                                })
                            }
                            ea.clear()
                            let changedVisiableEls = [...new Set(children.concat(groupElements).concat(arrows).concat(boundElements))]
                            changeElementsVisiable(visiable, changedVisiableEls)
                            // changeElementsVisiable(visiable, children.concat(arrows).concat(boundElements))
                            ea.copyViewElementsToEAforEditing(changedVisiableEls.concat([element]))
                            await ea.addElementsToView(false,false,false);
                        }
                        if (element.customData.mindmap.status == "open") {
                            recursion = true
                            visiable = false
                            status = "close"
                        } else {
                            recursion = event.ctrlKey
                            visiable = true
                            status = "open"
                        }
                        await op(recursion, visiable, status)

                        // ea.clear()
                        // elements = api.getSceneElements()
                        // ea.copyViewElementsToEAforEditing(elements);
                        rootNode = obj.rootNode
                        children = []
                        arrows = []
                        getChildren(rootNode, true, (el) => {
                            el = elementMap.get(el.id)
                            return el&&el.opacity == 0
                        })
                        

                        script = ea.plugin.scriptEngine.getListofScripts().filter((el) => {return el.basename == 'Mindmap format2'})[0]
                        content = await app.vault.read(script);
                        window.customData.Mindmap.treeElements = children.concat(arrows).concat([rootNode]).map((el) => {return elementMap.get(el.id)})
                        window.customData.Mindmap.treeElements = window.customData.Mindmap.treeElements.filter(el => el)
                        ea.plugin.scriptEngine.executeScript(ea.targetView, content, ea.plugin.scriptEngine.getScriptName(script), script)
                        // api.App.deselectElements()
                    }
                }
            }
        })
        
    }
}
