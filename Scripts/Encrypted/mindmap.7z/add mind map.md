/*
```javascript
*/

console.log("mindmap")
const api = ea.getExcalidrawAPI();
const selectedEls = ea.getViewSelectedElements();

if (selectedEls.length > 0 && selectedEls[0]?.customData?.mindmap) {
  window.customData = window.customData || {}
  window.customData.Mindmap = window.customData?.Mindmap || {}
  window.customData.Mindmap.mindmapPosMap = window.customData.Mindmap?.mindmapPosMap || new Map()
  window.customData.Mindmap.mindmapPosMap.set(selectedEls[0].customData.mindmap.root, null)
  selectedEls.forEach((el) => {
    if (el?.customData?.mindmap)
      delete el.customData.mindmap
  })
  
  return;
}

await ea.copyViewElementsToEAforEditing(selectedEls)
function getRoot(element, recursion=true) {
    arrowElements = selectedEls.filter((el) => {return el.type=="arrow"})
    arrowElements = arrowElements.filter((el) => {return el.endBinding && el.endBinding.elementId==element.id})
    if (arrowElements.length == 0) {
      return ea.getElement(element.id)
    }

    let parentElements = arrowElements.map((el) => {
        return ea.getElement(el.startBinding.elementId)
    })

    if (recursion) {
        return getRoot(parentElements[0], true)
    }
}

let rootEl = getRoot(selectedEls[0])
function traverse(element, parentId, level) {
    arrowElements = selectedEls.filter((el) => {return el.type=="arrow"})
    arrowElements = arrowElements.filter((el) => {return el.startBinding && el.startBinding.elementId==element.id})

    let childrenElements = arrowElements.map((el) => {
        return ea.getElement(el.endBinding.elementId)
    })

    element.customData = {
      ...element.customData,
      mindmap: {
        status: "open",
        root: rootEl.id,
        parent: parentId,
        level: level
      }
    }

    childrenElements.forEach((el) => {
      traverse(el, element.id, level+1)
    })

}
traverse(rootEl, null, 1)

// selectedEls.forEach((el) => {
// el.customData = {
//   ...el.customData,
//   mindmap: {
//     status: "open",
//     root: rootEl.id,
//     parent: el.parent}
//   }
// })


// ea.copyViewElementsToEAforEditing(selectedEls);
ea.addElementsToView();
new Notice("Add customData mindmap");

/*
```javascript
*/


