/*
```javascript
*/
//utility & convenience functions
let api = ea.getExcalidrawAPI()
console.log("onKeyDownHook") 
let settings = ea.getScriptSettings();
//set default values on first run
if (!settings["onKeyDown MindMap Format"]) {
  settings = {
    "onKeyDown MindMap Format": {
      value: "Excalidraw/onKeyDown MindMap Format",
      description: "",
    },
    "color decay level": {
      value: 4,
      description: "color decay level",
    }, 
  };
  ea.setScriptSettings(settings);
}

ea.setView("active")
class Node {
    constructor(element) {
        this.parent = null
        this.parentArrow = null
        this.children = []
        this.childrenArrow = []
        this.level = element.customData.mindmap.level
        this.id = element.id
    }
}

function getChildren(node, recursion=true, filter=undefined) {
    if (filter && node.children.length && filter(node.children[0])) {
        return
    }
    children = children.concat(node.children)
    arrows = arrows.concat(node.childrenArrow)
    
    if (recursion) {    
        node.children.forEach(el => {
            getChildren(el, true, filter)
        })
    }
}

function addNewNode(newEl, arrowEl, parentNode, obj) {
    node = new Node(newEl)  
    node.parent = parentNode
    node.parentArrow = arrowEl
    obj.NodeMap.set(node.id, node)
    if (parentNode) {
        parentNode.childrenArrow.push(arrowEl)
        parentNode.children.push(node)
    }
    return node
}

async function updateVisibility() {
    script = ea.plugin.scriptEngine.getListofScripts().filter((el) => {return el.basename == 'updateVisibility'})[0]
    content = await app.vault.read(script);
    ea.plugin.scriptEngine.executeScript(ea.targetView, content, ea.plugin.scriptEngine.getScriptName(script), script)
}

function maybeGenerateObj(element, rootEl, arrowElements) {
    if (!(window?.customData?.Mindmap?.mindmapPosMap.has(element.customData.mindmap.root)) || !window?.customData?.Mindmap?.mindmapPosMap.get(element.customData.mindmap.root)) {
        window.customData=window?.customData || {}; window.customData.Mindmap = window.customData?.Mindmap || {}
        window.customData.Mindmap.mindmapPosMap = window.customData.Mindmap?.mindmapPosMap || new Map()
        let obj = {}
        obj.NodeMap = new Map()

        function traverse(element, parentNode, level, arrow) {
            startArrowElements = arrowElements.filter((el) => {return el.startBinding && el.startBinding.elementId==element.id})
            if (!element?.customData?.mindmap) {
                element.customData = {
                    ...element.customData,
                    mindmap: {
                        status: "open",
                        root: rootEl.id,
                        parent: parentNode.id,
                        level: parentNode.level+1
                    }
                }
            }
            let node = addNewNode(element, arrow, parentNode, obj)
            if (level == 1) obj.rootNode = node
            startArrowElements.forEach((el) => {
                node.childrenArrow.push(el)
                let child = ea.getElement(el.endBinding.elementId)
                traverse(child, node, level+1, el)
            })
        }
        traverse(rootEl, null, 1)
        window.customData.Mindmap.mindmapPosMap.set(element.customData.mindmap.root, obj)
    }
}
ea.onKeyDownHook = async function(App, event, ea, view) {
    // console.log("onKeyDownHook") 

    const selectedEl = ea.getViewSelectedElement();
    if (["Tab", "Enter"].includes(event.code)) {
        while (true) {
            if (selectedEl) {
            if (selectedEl?.customData?.mindmap) {
                const state = api.getAppState();
                // if (!api) api = ea.getExcalidrawAPI();
                elements = ea.getViewElements()
                ea.clear();
                ea.copyViewElementsToEAforEditing(elements);
                arrowElements = elements.filter((el) => {return el.type=="arrow"})
                element = ea.getElement(selectedEl.id)
                rootEl = ea.getElement(element.customData.mindmap.root)
                maybeGenerateObj(element, rootEl, arrowElements)
                obj = window.customData.Mindmap.mindmapPosMap.get(element.customData.mindmap.root)
                currentNode = obj.NodeMap.get(element.id)
                newEls = []
                parentEl = undefined
                parentNode= undefined
                level = undefined
                if (event.code =="Tab") {
                    parentNode = currentNode
                    newElX = element.x + element.width + 20
                    newElY = element.y
                    level = element.customData.mindmap.level+1
                    event.key ="Enter"
                //Tab end
                }
                if (event.code =="Enter") {
                    parentNode = currentNode.parent
                    newElX = element.x
                    newElY = element.y + element.height + 20
                    level = element.customData.mindmap.level
                }

                parentEl = ea.getElement(parentNode.id)

                if(event.code == "Enter") {
                    ea.style.backgroundColor = element.backgroundColor
                } else {
                    cm = ea.getCM(parentEl.backgroundColor);
                    if (level == 1) {

                    } else {
                        ea.style.backgroundColor = level <= Number(settings["color decay level"].value) ? cm.lightnessTo(Math.min(cm.lightness+20, 255)).stringHEX({alpha:false}) : parentEl.backgroundColor;
                    }
                }
                ea.style.strokeWidth = selectedEl.strokeWidth;
                ea.style.roughness = selectedEl.roughness;
                ea.style.fillStyle = selectedEl.fillStyle
                ea.style.roundness =selectedEl.roundness
                // ea.style.fontSize    = selectedEl.fontSize;
                ea.style.fontFamily  = state.currentItemFontFamily

                id = ea.addText(newElX, newElY, "new element", {box:true,textAlign: "center", textVerticalAlign: "middle", boxStrokeColor: "black"});
                newEl = ea.getElement(id)
                if(event.code == "Enter") {
                    newEl.width = element.width
                    newEl.height = element.height
                }
                newEl.customData = {
                    mindmap: {
                        status: "open",
                        root: rootEl.id,
                        parent: parentNode.id,
                        level: level
                    }
                }

                id = ea.connectObjects(parentNode.id, "right", newEl.id,"left",{startArrowHead: 'dot'});
                let arrowEl = ea.getElement(id)
                ea.addElementsToView(false, false, false);
                addNewNode(newEl, arrowEl, parentNode, obj)
                newEls.push(newEl)
                newEls.push(arrowEl)

                rootNode = obj.rootNode
                children = []
                arrows = []
                getChildren(rootNode, true, (el) => {
                    el = ea.getElement(el.id)
                    return el&&el.opacity == 0
                })

                ea.selectElementsInView([newEl]);
                // api.App.startTextEditing()

                script = ea.plugin.scriptEngine.getListofScripts().filter((el) => {return el.basename == 'Mindmap format2'})[0]
                content = await app.vault.read(script);
                window.customData.Mindmap.treeElements = children.concat(arrows).concat([rootNode]).
                concat(newEls).map((el) => {return ea.getElement(el.id)})
                console.log(window.customData.Mindmap.treeElements)
                ea.plugin.scriptEngine.executeScript(ea.targetView, content, ea.plugin.scriptEngine.getScriptName(script), script)
                
                return false;
            }
            else {
                let elements = ea.getViewElements()
                let arrowElements = elements.filter(el => el.type=="arrow")
                let arrowEl = arrowElements.filter(el => 
                    el?.endBinding?.elementId == selectedEl.id
                )[0]
                if (arrowEl?.startBinding?.elementId) {
                    let parentEl = elements.filter(el => el.id == arrowEl.startBinding.elementId)[0] 
                    selectedEl.customData = {
                        ...selectedEl.customData,
                        mindmap : {
                            status: "open",
                            root: parentEl?.customData?.mindmap?.root,
                            parent: parentEl.id,
                            level: parentEl?.customData?.mindmap?.level+1
                        }
                    }
                    let rootEl = elements.filter(el => 
                        el.id== parentEl.customData.mindmap.root
                    )[0]
                    ea.clear()
                    ea.copyViewElementsToEAforEditing(elements);
                    maybeGenerateObj(selectedEl, rootEl, arrowElements)
                    let obj = window.customData.Mindmap.mindmapPosMap.get(selectedEl.customData.mindmap.root)
                    let parentNode = obj.NodeMap.get(parentEl.id)
                    addNewNode(selectedEl, arrowEl, parentNode, obj)
                    continue;
                }
            }
            }
            break;
        }
        return false;
    }
    
    if (["BracketLeft", "BracketRight"].includes(event.code) && !event.ctrlKey && !event.altKey && !event.shiftKey) {
        window.customData = window.customData || {}
        window.customData.animation = window.customData.animation || {lastVisibleIndex : -1, lock: false}
        if (event.code =="BracketLeft") {
            window.customData.animation.lastVisibleIndex = Math.max(window.customData.animation.lastVisibleIndex - 1, -1)
            updateVisibility()
        }
        else if (event.code =="BracketRight") {
            window.customData.animation.lastVisibleIndex += 1
            updateVisibility()
        }
    }
    if (["Comma", "Period"].includes(event.code) && !event.ctrlKey && !event.altKey && !event.shiftKey && selectedEl?.customData?.gif) {
        console.log("BracketRight")
        let drawing = window.gifMap?.get(selectedEl.id)
        if (event.code =="Comma") {
            drawing.frameIndex = drawing.frameIndex == 0 ? drawing.gifFrames.length - 1: drawing.frameIndex - 1;
        }
        else if (event.code =="Period") {
            drawing.frameIndex = (drawing.frameIndex + 1) % drawing.gifFrames.length;
        }
        window.keyDown = true
        api = ea.getExcalidrawAPI();
        setTimeout(function() { 
          ea.viewUpdateScene({
            appState: {
                zoom:{value: api.getAppState().zoom.value},
            },
          // elements: JSON.parse(JSON.stringify(ea.getViewElements()))
            })
        })
        
    }
    
    return false;
    
}