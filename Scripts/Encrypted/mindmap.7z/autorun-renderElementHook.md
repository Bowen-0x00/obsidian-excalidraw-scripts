/*
```javascript
*/
console.log("autorun-renderElementHook")
ea.setView("active");
let api = ea.getExcalidrawAPI();
            
// state.zoom = {value: 0.8}
// drawElementOnCanvasHook(context, rc, element, shape, renderConfig)
// renderElementHook

function setShadow(element, shadow, context, zoom) {
    let deltaColor = parseInt(shadow.shadowColor)
    if (deltaColor) {
        cm = ea.getCM(element.backgroundColor);
        context.shadowColor = cm.lightnessTo(Math.max(cm.lightness+deltaColor, 0)).stringHEX({alpha:false})
    } else {
        context.shadowColor = shadow.shadowColor
    }
    maxSize = Math.max(element.width, element.height)
    let shadowBlur = parseFloat(shadow.shadowBlur)
    if (!isNaN(shadow.shadowBlur)) {
        shadowBlur = maxSize * shadowBlur
    }
    let shadowOffsetX = parseFloat(shadow.shadowOffsetX)
    if (!isNaN(shadow.shadowOffsetX)) {
        shadowOffsetX = element.width * shadowOffsetX
    }
    let shadowOffsetY = parseFloat(shadow.shadowOffsetY)
    if (!isNaN(shadow.shadowOffsetY)) {
        shadowOffsetY = element.height * shadowOffsetY
    }
    
    context.shadowBlur = shadowBlur*zoom;
    context.shadowOffsetX = shadowOffsetX*zoom;
    context.shadowOffsetY = shadowOffsetY*zoom;
}
window.renderElementHook_before=function(element,rc,context,renderConfig,appState, getElementAbsoluteCoords, drawElementFromCanvas
  ) {
    // console.log("renderElementHook_before")
    if (window?.customData?.hover?.ids?.includes(element.id)) {
        context.save()
        setShadow(element, window.customData.hover.shadow, context, appState.zoom.value)
    }
    if (element.customData) {
        // console.log("renderElementHook_before")
        if ("shadow" in element.customData && !window?.customData?.hover?.ids?.includes(element.id)) {
            context.save()
            setShadow(element, element.customData.shadow, context, appState.zoom.value)
        } 

    } 
    if (element.type == "arrow" && element?.startBinding?.elementId && element.opacity==0) {
        if (!api) api = ea.getExcalidrawAPI();
        elements = api.getSceneElements()
        ea.clear();
        ea.copyViewElementsToEAforEditing(elements);
        startEl = ea.getElement(element.startBinding.elementId)

        if (startEl?.customData?.mindmap && startEl.opacity != 0) {
            context.save()
            let [x1, y1, x2, y2] = getElementAbsoluteCoords(startEl)
            const cx = ((x1 + x2) / 2 + appState.scrollX);
            const cy = ((y1 + y2) / 2 + appState.scrollY);
            let shiftX = (x2 - x1) / 2 - (startEl.x - x1);
            let shiftY = (y2 - y1) / 2 - (startEl.y - y1);
            context.translate(cx, cy);
            context.rotate(startEl.angle);
            context.translate(shiftX, 0);//right

            context.beginPath();
            context.arc(0, 0, 10, 0, 2 * Math.PI, false);
            context.fillStyle = '#ffd8a8';
            context.fill();
            context.lineWidth = 3;
            context.strokeStyle = '#ffa94d';
            context.stroke();
            context.restore()
        }


    }  
    if (window.customData?.layers) {
        let showLayers = window.customData.layer.layers.showLayers.toLowerCase()
        if (showLayers != 'all') {
            context.save()
            context.font = `${48/appState.zoom.value}px serif`;
            context.fillText(`Show layers: ${showLayers}`, 10/appState.zoom.value, 50/appState.zoom.value);
            context.restore()
            lastShowLayers = showLayers
        }
    } 
    if (window.roughjsDrawHook) {
        window.roughjsDrawHook.context = context
        window.roughjsDrawHook.renderConfig = renderConfig
        window.roughjsDrawHook.appState = appState
        window.roughjsDrawHook.drawElementFromCanvas = drawElementFromCanvas
        window.roughjsDrawHook.element = element
    }
}

window.renderElementHook_after=function(element,rc,context,renderConfig,appState,
    ) {
    if (element.customData) {
        if ("shadow" in element.customData) {
            context.restore()
        }
        if (window?.customData?.hover?.ids?.includes(element.id)) {
            context.restore()
        }
        if ("animation" in element.customData) {
            // ea.copyViewElementsToEAforEditing([element])
            // ea.addElementsToView(false,false,false);
        }

    }

}