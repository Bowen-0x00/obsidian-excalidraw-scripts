/*
```javascript
*/
window.customData.Mindmap = undefined
